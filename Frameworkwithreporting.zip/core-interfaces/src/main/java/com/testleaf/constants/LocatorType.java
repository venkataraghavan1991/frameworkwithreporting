package com.testleaf.constants;

public enum LocatorType {

	ID,
	NAME,
	CLASS,
	XPATH,
	LINK_TEXT
}
