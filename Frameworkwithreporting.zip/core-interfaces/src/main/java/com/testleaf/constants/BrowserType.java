package com.testleaf.constants;

public enum BrowserType {
	CHROME,
	FIREFOX
}
