package testcases;

import org.testng.annotations.Test;

import data.RedisDataEngine;
import pages.BasePage;
import pages.LeadsPage;

public class TC004_DeleteLead extends BasePage {
	

	@Test()
	public void runDeleteLead() throws InterruptedException {
				
		new LeadsPage()
				.clickFindLeadsLink()
				.enterLeadID(leadInfo.getLeadId())
				.clickFindLeadButton()
				.clickFirstLead()
				.clickDeleteButton()
				.clickFindLeadsLink()
				.clickLeadIDTab()
				.enterLeadID(leadInfo.getLeadId())
				.clickFindLeadButton()
				.verifyDeletedLeadID();
		
		RedisDataEngine.deleteLeadRedis(leadInfo.getLeadId());

		
	}
}
