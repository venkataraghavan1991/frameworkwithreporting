package testcases;

import org.testng.annotations.Test;

import data.LeadInfo;
import data.RedisDataEngine;
import pages.BasePage;
import pages.LeadsPage;

public class TC005_MergeLeads extends BasePage {

	
	@Test()
	public void runMergeLead() throws InterruptedException {
		
		// Get the record from redis other than first lead id
		LeadInfo secondLeadInfo = RedisDataEngine.getRandomLeadRedis(leadInfo.getLeadId());
		
		System.out.println(leadInfo.getLeadId());
		System.out.println(secondLeadInfo.getLeadId());

		try {
			new LeadsPage()
			.clickMergeLeadLink()
			.typeFromLead(leadInfo.getLeadId())
			.typeToLead(secondLeadInfo.getLeadId())
			.clickMergeButton()
			.verifyCompanyName(secondLeadInfo.getCompanyName())
			.clickFindLeadsLink()
			.enterLeadID(leadInfo.getLeadId())
			.clickFindLeadButton()
			.verifyDeletedLeadID();
			
			RedisDataEngine.deleteLeadRedis(leadInfo.getLeadId());

		} catch (Exception e) {
			RedisDataEngine.saveLeadRedis(leadInfo);
			throw e;
		}
		

		
		

	}
}
