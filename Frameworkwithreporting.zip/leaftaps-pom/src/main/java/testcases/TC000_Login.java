package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import data.CombinedDataEngine;
import data.RedisDataEngine;
import pages.BasePage;
import pages.LeadsPage;
import pages.LoginPage;

public class TC000_Login extends BasePage {

	@BeforeClass
	public void setTestName() {
		testcaseName = "Login";
	}
	
	@BeforeMethod
	public void setup() {
    	leadInfo = CombinedDataEngine.fetchData();

		
		
	}
   
    @Test(invocationCount = 1)
    public void runLogin() {
        
    	new LoginPage()
		.enterUsername("demosalesmanager")
		.enterPassword("crmsfa")
		.clickLogin();
    		
    }
}
