package testcases;

import org.testng.annotations.Test;
import pages.BasePage;
import pages.LeadsPage;

public class TC003_DuplicateLead extends BasePage {

	@Test
	public void runDuplicateLead() throws InterruptedException {
		
		new LeadsPage()
			.clickFindLeadsLink()
			.clickPhoneTab()
			.enterPhoneNumber(leadInfo.getPhoneNumber())
			.clickFindLeadButton()
			.clickFirstLead()
			.clickDuplicateButton()
			.clickCreateDuplicate()
			.verifyCompanyName(leadInfo.getCompanyName());

	}
}
