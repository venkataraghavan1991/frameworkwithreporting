package data;

public class CombinedDataEngine {
	
	public static LeadInfo fetchData() {
		
		LeadInfo leadsInfo = FakerDataEngine.getLeadInfo();
		if(RedisDataEngine.getLeadsCount() > 0) {
			LeadInfo randomLeadRedis = RedisDataEngine.getRandomLeadRedis();
			leadsInfo.setLeadId(randomLeadRedis.getLeadId());
		}
		return leadsInfo;
	}

}
