package data;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.logging.Logger;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class RedisDataEngine {
	
	// make a connection 
	static Jedis jedis = new Jedis("localhost",6379);
	private static final Logger logger = Logger.getLogger(RedisDataEngine.class.getName());
	
	/**
	 * Push the record into redis keys (table)
	 * {@link LeadInfo} - The class that has all data information about the Lead
	 * Key : LeadId is the unique parameter (Hset) >> O(1)
	 * 
	 */
	public static void saveLeadRedis(LeadInfo leadInfo) {
		
		// Get the lead id as key
		String leadId = "Lead: "+leadInfo.getLeadId();
		
		jedis.hset(leadId, "companyName", leadInfo.getCompanyName());
		jedis.hset(leadId, "firstName", leadInfo.getFirstName());
		jedis.hset(leadId, "lastName", leadInfo.getLastName());
		jedis.hset(leadId, "phoneNumber", leadInfo.getPhoneNumber());
		
		logger.info("The lead "+leadId+" is stored in the redis");
		
	}
	
	/**
	 * Fetch the lead records (key info) from Redis - only one !!
	 * Top 1 or Random one ?
	 */
	public static LeadInfo getRandomLeadRedis() {
		String leadId = null;
		
		// Get all the keys
		Set<String> leadKeys = jedis.keys("Lead:*");
		
		// Get first lead and get all lead info from redis
		if(!leadKeys.isEmpty()) {
			
			 // Convert Set to List for random access
	        List<String> leadKeysList = new ArrayList<>(leadKeys);

	        // Get a random key
	        Random random = new Random();
	        leadId = leadKeysList.get(random.nextInt(leadKeysList.size()));
			
		} else {
			throw new RuntimeException("There are no leads matching in the redis");
		}
		
		// LeadInfo
		return extractLeadInfo(leadId);
		
	}
	
	 /**
     * Fetches a random lead from Redis excluding the specified LeadId.
     * 
     * @param excludeLeadId The LeadId to exclude from selection.
     * @return LeadInfo object containing lead details.
     */
    public static LeadInfo getRandomLeadRedis(String excludeLeadId) {
        Set<String> leadKeys = jedis.keys("Lead:*");
        String leadId = null;

        if (!leadKeys.isEmpty()) {
            // Remove the excluded LeadId
            String excludeKey = "Lead:" + excludeLeadId;
            leadKeys.remove(excludeKey);

            if (leadKeys.isEmpty()) {
                throw new RuntimeException("No leads available in Redis excluding LeadId: " + excludeLeadId);
            }

            // Convert Set to List for random access
            List<String> leadKeysList = new ArrayList<>(leadKeys);

            // Get a random key
            Random random = new Random();
            leadId = leadKeysList.get(random.nextInt(leadKeysList.size()));
        } else {
            throw new RuntimeException("There are no leads matching in Redis.");
        }

        // Extract LeadInfo
        return extractLeadInfo(leadId);
        
    }

    /**
     * Extracts LeadInfo from a given lead key.
     * 
     * @param leadKey The Redis key for the lead.
     * @return LeadInfo object populated with lead details.
     */
    private static LeadInfo extractLeadInfo(String leadId) {
        LeadInfo leadInfo = new LeadInfo();
		leadInfo.setLeadId(leadId.replaceAll("Lead: ", ""));
		leadInfo.setCompanyName(jedis.hget(leadId, "companyName"));
		leadInfo.setFirstName(jedis.hget(leadId, "firstName"));
		leadInfo.setLastName(jedis.hget(leadId, "lastName"));
		leadInfo.setPhoneNumber(jedis.hget(leadId, "phoneNumber"));
		
        return leadInfo;
    }
	
	/**
	 * Delete an existing record from redis
	 * @return 
	 * @return 
	 */
	public static void deleteLeadRedis(String leadId) {
		String deleteLeadId = "Lead: "+leadId;
		
		if(jedis.exists(deleteLeadId)) {
			jedis.del(deleteLeadId);
			logger.info("The lead "+leadId+" is removed from redis");
		}
	}
	
	
	public static LeadInfo getLeadRedis(String leadId) {
		// LeadInfo
		LeadInfo leadInfo = new LeadInfo();
		leadInfo.setLeadId(leadId.replaceAll("Lead: ", ""));
		leadInfo.setCompanyName(jedis.hget(leadId, "companyName"));
		leadInfo.setFirstName(jedis.hget(leadId, "firstName"));
		leadInfo.setLastName(jedis.hget(leadId, "lastName"));
		leadInfo.setPhoneNumber(jedis.hget(leadId, "phoneNumber"));
		
		return leadInfo;
		
	}
	
	public static int getLeadsCount() {
		Set<String> leadKeys = jedis.keys("Lead:*");
		return leadKeys.size();
	}
	
	
	
}
