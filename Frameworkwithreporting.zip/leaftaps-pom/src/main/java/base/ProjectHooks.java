package base;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.testleaf.constants.BrowserTestEngine;
import com.testleaf.constants.BrowserType;
import com.testleaf.drivers.manager.DriverManager;
import com.testleaf.reporting.config.ReportingConfig;
import com.testleaf.reporting.factory.ReportFactory;
import com.testleaf.reporting.reporters.Reporter;
import com.testleaf.web.browser.Browser;

import config.ConfigurationManager;
import listeners.RetryContext;

public class ProjectHooks {

    public String leadID;
    public static Reporter reporter;
    public String testcaseName;

    private static ThreadLocal<Browser> browser = new ThreadLocal<>();
    private static ThreadLocal<BrowserTestEngine> whichBrowserEngine = new ThreadLocal<>();
    private static ThreadLocal<BrowserType> whichBrowser = new ThreadLocal<>();

    public static Browser getBrowser() {
        return browser.get();
    }
    
    public static BrowserTestEngine getBrowserEngine() {
        return whichBrowserEngine.get();
    }
    
    public static BrowserType getBrowserType() {
        return whichBrowser.get();
    }
    
    @BeforeSuite
    public void beforeSuite() {
    	Map<String, Boolean> reportConfig = new HashMap<>();
    	reportConfig.put("reporting.allure.enabled", ConfigurationManager.configuration().isAllureEnabled());
    	reportConfig.put("reporting.extent.enabled", ConfigurationManager.configuration().isExtentEnabled());
    	ReportingConfig config = new ReportingConfig(reportConfig);
    	reporter = ReportFactory.createReporter(config);
    }
        
    @BeforeMethod
    @Parameters({"browserEngine", "browserType"})
    public void preCondition(@Optional("SELENIUM") String browserEngineParam, @Optional("CHROME") String browserTypeParam) {
        BrowserTestEngine browserEngine = BrowserTestEngine.valueOf(browserEngineParam.toUpperCase());
        BrowserType browserType = BrowserType.valueOf(browserTypeParam.toUpperCase());
        
        // Check if it is retrying the test using RetryContext
        if(RetryContext.isRetry()) {
            System.out.println("The test is being retried");
            browserEngine = switchBrowserEngine(browserEngine);
            browserType = switchBrowserType(browserType);
            
            // Reset the retry flag after switching
            RetryContext.reset();
        }

        // Get the browser instance from DriverManager
        Browser br = DriverManager.getBrowser(browserEngine, browserType);
        browser.set(br);
        whichBrowserEngine.set(browserEngine);
        whichBrowser.set(browserType);
        
        //Start the reporting
        reporter.startTestcase(testcaseName);
        
        // Navigate to the URL and maximize
        getBrowser().navigateTo(ConfigurationManager.configuration().url());
        getBrowser().maximize();
        
        // Register alert
        if(browserEngine == BrowserTestEngine.PLAYWRIGHT) {
            getBrowser().acceptAlert();
        }
    }

    private BrowserType switchBrowserType(BrowserType browserType) {
        if(browserType == BrowserType.CHROME) {
            return BrowserType.FIREFOX;
        } else {
            return BrowserType.CHROME;
        }
    }

    private BrowserTestEngine switchBrowserEngine(BrowserTestEngine browserEngine) {
        if(browserEngine == BrowserTestEngine.PLAYWRIGHT) {
            return BrowserTestEngine.SELENIUM;
        } else {
            return BrowserTestEngine.PLAYWRIGHT;
        }
    }

    @AfterMethod
    public void postCondition() {
        getBrowser().closeBrowser();
        reporter.endTestcase(testcaseName);
    }

}
