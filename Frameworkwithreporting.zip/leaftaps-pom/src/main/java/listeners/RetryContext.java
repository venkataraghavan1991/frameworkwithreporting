package listeners;

public class RetryContext {
    private static ThreadLocal<Boolean> isRetry = ThreadLocal.withInitial(() -> false);
    
    public static void setRetry(boolean retry) {
        isRetry.set(retry);
    }
    
    public static boolean isRetry() {
        return isRetry.get();
    }
    
    public static void reset() {
        isRetry.remove();
    }
}
