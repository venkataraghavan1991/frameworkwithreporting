package listeners;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryListener implements IRetryAnalyzer{
	
	private int retryCount = 0;
	private final int retryLimit = 1;
	
	@Override
	public boolean retry(ITestResult result) {
		if(!result.isSuccess() && retryCount < retryLimit) {
			retryCount++;
			RetryContext.setRetry(true);
			System.out.println("Retrying test: " + result.getName() + " with retry count " + retryCount);
			return true;
		}
		return false;
	}
}
