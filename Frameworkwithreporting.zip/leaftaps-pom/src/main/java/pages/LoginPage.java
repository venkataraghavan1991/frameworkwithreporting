package pages;

import com.testleaf.constants.BrowserTestEngine;
import com.testleaf.constants.LocatorType;

import base.ProjectHooks;
import config.ConfigurationManager;

public class LoginPage extends ProjectHooks {

    public LoginPage enterUsername(String username) {
        getBrowser().locateEdit(LocatorType.NAME, "USERNAME").type(username);
        reporter.reportStep("The username typed correctly", true, getBrowser().getScreenshot());
        return this;
    }

    public LoginPage enterPassword(String password) {
        getBrowser().locateEdit(LocatorType.NAME, "PASSWORD").type(password);
        return this;
    }

    public WelcomePage clickLogin() {
        getBrowser().locateButton(LocatorType.XPATH, "//input[@value='Login']").click();
        return new WelcomePage();
    }
    
    public HomePage doLogin() {
    	
    	if(getBrowserEngine() == BrowserTestEngine.SELENIUM) {
	    	try {
				getBrowser().loadStorageState();
	    	} catch (Exception e) {
				//e.printStackTrace();
			}
    	}
		getBrowser().navigateTo(ConfigurationManager.configuration().appUrl());

    	if(!getBrowser().getTitle().contains("My Home")) {
    		
	    	//login to the application	
    		enterUsername(ConfigurationManager.configuration().userName())
    			.enterPassword(ConfigurationManager.configuration().password())
    			.clickLogin();
    		
    		// save the storage state
    		getBrowser().saveStorageState();
	    		
    	}
    	return new HomePage();
    }
    
}
