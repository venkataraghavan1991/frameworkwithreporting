package pages;

import com.testleaf.constants.BrowserTestEngine;
import com.testleaf.constants.LocatorType;
import com.testleaf.web.element.Edit;

public class MergeLeadPage extends BasePage {
	
	
	public MergeLeadPage typeFromLead(String lead) throws InterruptedException {
		Thread.sleep(500);
		Edit fromLead = getBrowser().locateEdit(LocatorType.XPATH, "//input[@id='ComboBox_partyIdFrom']");
		fromLead.type(lead);
		fromLead.pressEnter();
		return this;
	}

	public MergeLeadPage typeToLead(String lead) throws InterruptedException {
		Thread.sleep(500);
		getBrowser().locateEdit(LocatorType.XPATH, "//input[@id='ComboBox_partyIdTo']").type(lead);
		getBrowser().locateEdit(LocatorType.XPATH, "//input[@id='ComboBox_partyIdTo']").pressEnter();
		return this;
	}

	public MergeLeadPage clickFromLead() throws InterruptedException {
		getBrowser().locateLink(LocatorType.XPATH, "(//img[@alt='Lookup'])[1]").click();
		return this;
	}

	public MergeLeadPage clickToLead() throws InterruptedException {
		getBrowser().locateLink(LocatorType.XPATH, "(//img[@alt='Lookup'])[2]").click();
		return this;

	}

	public MergeLeadPage clickFindleadsButton() throws InterruptedException {
		getBrowser().locateButton(LocatorType.XPATH, "//button[text()='Find Leads']").click();
		return this;
	}

	public MergeLeadPage clickToFindleadsButton() throws InterruptedException {
		getBrowser().locateButton(LocatorType.XPATH, "//button[text()='Find Leads']").click();
		return this;
	}

	public MergeLeadPage clickFirstLead() throws InterruptedException {
		Thread.sleep(500);
		getBrowser().locateLink(LocatorType.XPATH, "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]").click();
		return this;
	}

	public MergeLeadPage enterFirstName(String firstName) throws InterruptedException {
		getBrowser().locateEdit(LocatorType.XPATH, "(//input[@name='firstName'])[1]").type(firstName);
		return this;
	}

	public MergeLeadPage getLeadID() throws InterruptedException {
		leadID = getBrowser().locateElement(LocatorType.XPATH, "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]/div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").getText();
		System.out.println(leadID);
		return this;
	}


	public ViewLeadPage clickMergeButton() throws InterruptedException {
		getBrowser().locateLink(LocatorType.XPATH, "//a[text()='Merge']").click();
		if(getBrowserEngine() == BrowserTestEngine.SELENIUM) getBrowser().acceptAlert();
		return new ViewLeadPage();
	}

}
