package pages;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import base.ProjectHooks;
import data.CombinedDataEngine;
import data.LeadInfo;

public class BasePage extends ProjectHooks{
	
	protected LeadInfo leadInfo;
	
	@BeforeMethod
	public void setup() {
    	leadInfo = CombinedDataEngine.fetchData();

		new LoginPage()
		.doLogin()
        .clickLeadsTab();
		
	}
	
	@AfterMethod
	public void tearDown() {
		
	}

}
