package pages;

import com.testleaf.constants.LocatorType;

public class LeadsPage extends BasePage {

    public CreateLeadPage clickCreateLeadLink() {
        try {
			getBrowser().locateLink(LocatorType.LINK_TEXT, "Create Lead").click();
	        reporter.reportStep("Create Lead link clicked successfully", true, getBrowser().getScreenshot());
		} catch (Exception e) {
	        reporter.reportStep("Create Lead Link", "Click failed with reason "+e, false);
	        throw e;
		}
        return new CreateLeadPage();
    }

    public FindLeadPage clickFindLeadsLink() {
        getBrowser().locateLink(LocatorType.LINK_TEXT, "Find Leads").click();
        return new FindLeadPage();
    }

    public MergeLeadPage clickMergeLeadLink() {
    	getBrowser().locateLink(LocatorType.LINK_TEXT, "Merge Leads").click();
        return new MergeLeadPage();
    }
    
    
}
