package com.testleaf.reporting.reporters;

import java.util.Set;

public class CompositeReporter implements Reporter{
	
	private Set<Reporter> reporterSet;
	
	public CompositeReporter(Set<Reporter> reporterSet) {
		this.reporterSet = reporterSet;
	}

	@Override
	public void startTestcase(String testcaseName) {
		reporterSet.forEach(r -> r.startTestcase(testcaseName));
	}

	@Override
	public void reportStep(String stepName, String message, boolean status) {
		reporterSet.forEach(r -> r.reportStep(stepName, message, status));

	}

	@Override
	public void reportStep(String message, boolean status, byte[] imageName) {
		reporterSet.forEach(r -> r.reportStep(message, status, imageName));
	}

	@Override
	public void addScreenShot(String stepName, byte[] imageName) {
		reporterSet.forEach(r -> r.addScreenShot(stepName, imageName));

	}

	@Override
	public void endTestcase(String testcaseName) {
		reporterSet.forEach(r -> r.endTestcase(testcaseName));
	}

}
