package com.testleaf.reporting.factory;

import java.util.HashSet;
import java.util.Set;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.testleaf.reporting.config.ReportingConfig;
import com.testleaf.reporting.reporters.AllureReportImpl;
import com.testleaf.reporting.reporters.CompositeReporter;
import com.testleaf.reporting.reporters.ExtentReportImpl;
import com.testleaf.reporting.reporters.Reporter;

public class ReportFactory {
	
	public static Reporter createReporter(ReportingConfig config) {
		
		Set<Reporter> reporterSet = new HashSet<Reporter>();
		
		if(config.isAllureEnabled()) {
			reporterSet.add(new AllureReportImpl());
		} 
		
		if(config.isExtentEnabled()) {
			ExtentSparkReporter spark = new ExtentSparkReporter("reports/extent.html");
			ExtentReports reports = new ExtentReports();
			reports.attachReporter(spark);
			reporterSet.add(new ExtentReportImpl(reports));

		} 
		
		if(reporterSet.size() == 0) {
			return null;
		} else {
			return new CompositeReporter(reporterSet);
		}
	}
	

}
