package com.testleaf.reporting.reporters;

import java.util.Base64;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

public class ExtentReportImpl implements Reporter{
	
	private ExtentReports report;
	private ExtentTest test;
	
	public ExtentReportImpl(ExtentReports report) {
		this.report = report;
	}

	@Override
	public void startTestcase(String testcaseName) {
		test = report.createTest(testcaseName);
	}

	@Deprecated
	@Override
	public void reportStep(String stepName, String message, boolean status) {
		if(status) {
			test.pass(stepName + ":" + message);
		} else {
			test.fail(stepName + ":" + message);
		}
	}

	@Override
	public void addScreenShot(String stepName, byte[] imageName) {
		test.addScreenCaptureFromBase64String(Base64.getEncoder().encodeToString(imageName));
	}

	@Override
	public void endTestcase(String testcaseName) {
		report.flush();
	}

	@Override
	public void reportStep(String message, boolean status, byte[] imageName) {
		String encodeToString = Base64.getEncoder().encodeToString(imageName);
		if(status) {
			test.log(Status.PASS, message, MediaEntityBuilder.createScreenCaptureFromBase64String(encodeToString).build());
		} else {
			test.log(Status.FAIL, message, MediaEntityBuilder.createScreenCaptureFromBase64String(encodeToString).build());
		}
		
	}

}
