package com.testleaf.reporting.config;

import java.util.Map;

public class ReportingConfig {
	
	private boolean allureEnabled;
	private boolean extentEnabled;
	
	public ReportingConfig(Map<String, Boolean> reportConfig) {
		this.allureEnabled = reportConfig.get("reporting.allure.enabled");
		this.extentEnabled = reportConfig.get("reporting.extent.enabled");
	}

	public boolean isAllureEnabled() {
		return allureEnabled;
	}

	public boolean isExtentEnabled() {
		return extentEnabled;
	}

}
