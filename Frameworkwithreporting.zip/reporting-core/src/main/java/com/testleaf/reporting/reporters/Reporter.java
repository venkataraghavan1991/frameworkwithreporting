package com.testleaf.reporting.reporters;

public interface Reporter {
	
	void startTestcase(String testcaseName);
	void reportStep(String stepName, String message, boolean status);
	void reportStep(String message, boolean status, byte[] imageName);
	void addScreenShot(String stepName, byte[] imageName);
	void endTestcase(String testcaseName);

}
