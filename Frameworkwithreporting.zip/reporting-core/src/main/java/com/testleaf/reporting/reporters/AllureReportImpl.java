package com.testleaf.reporting.reporters;

import java.io.ByteArrayInputStream;
import java.util.UUID;

import io.qameta.allure.Allure;

public class AllureReportImpl implements Reporter{
	
	private String testId;
	
	
	@Override
	public void startTestcase(String testcaseName) {
		testId = UUID.randomUUID().toString();
		Allure.getLifecycle().startTestCase(testId);
	}

	@Deprecated
	@Override
	public void reportStep(String stepName, String message, boolean status) {
		throw new UnsupportedOperationException("This method is not implemented in Allure");
	}

	@Override
	public void addScreenShot(String stepName, byte[] imageName) {
		Allure.addAttachment(stepName, "Byte/Image", new ByteArrayInputStream(imageName), "png");
	}

	@Override
	public void endTestcase(String testcaseName) {
		Allure.getLifecycle().stopTestCase(testId);
		Allure.getLifecycle().writeTestCase(testId);
	}

	@Override
	public void reportStep(String message, boolean status, byte[] imageName) {

		
	}
}
