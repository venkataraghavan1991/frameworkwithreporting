package com.testleaf.web.browser;

import java.io.File;
import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverListener;

public class EventListener implements WebDriverListener{
	
	private byte[] snapshot;

	@Override
	public void beforeAnyCall(Object target, Method method, Object[] args) {
		
	}

	@Override
	public void afterAnyCall(Object target, Method method, Object[] args, Object result) {
		
		if(target instanceof WebDriver) {
			WebDriver driver = (WebDriver) target;
			setSnapshot(((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES));
		}
	}

	public byte[] getSnapshot() {
		return snapshot;
	}

	private void setSnapshot(byte[] snapshot) {
		this.snapshot = snapshot;
	}

	
	
	
	

	
	

}
