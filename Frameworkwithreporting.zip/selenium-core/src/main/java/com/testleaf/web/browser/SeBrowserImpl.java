package com.testleaf.web.browser;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.EventFiringDecorator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.testleaf.constants.LocatorType;
import com.testleaf.web.element.SeButtonImpl;
import com.testleaf.web.element.SeEditImpl;
import com.testleaf.web.element.Button;
import com.testleaf.web.element.Edit;
import com.testleaf.web.element.Element;
import com.testleaf.web.element.SeElementImpl;
import com.testleaf.web.element.SeLinkImpl;
import com.testleaf.web.element.decorated.SeButtonLogDecorator;
import com.testleaf.web.element.decorated.SeButtonSnapDecorator;
import com.testleaf.web.element.Link;

public class SeBrowserImpl extends EventListener implements Browser {

	protected WebDriver driver;
	//private EventListener listener;

	public SeBrowserImpl(WebDriver driver) {
		//this.listener = new EventListener();
		//this.driver = new EventFiringDecorator<>(listener).decorate(driver);
		this.driver = driver;
	}

	@Override
	public void navigateTo(String url) {
		this.driver.get(url);
		this.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	@Override
	public void maximize() {
		this.driver.manage().window().maximize();
	}

	@Override
	public void closeBrowser() {
		this.driver.close();
	}

	private WebElement findElement(LocatorType locatorType, String locator) {
		switch (locatorType) {
		case ID:
			return this.driver.findElement(By.id(locator));
		case NAME:
			return this.driver.findElement(By.name(locator));
		case CLASS:
			return this.driver.findElement(By.className(locator));
		case LINK_TEXT:
			return this.driver.findElement(By.linkText(locator));
		case XPATH:
			return this.driver.findElement(By.xpath(locator));
		default:
			throw new IllegalArgumentException("Unsupported Locator Type :" + locatorType);
		}
	}

	@Override
	public Element locateElement(LocatorType locatorType, String element) {
		return new SeElementImpl(findElement(locatorType, element));
	}

	@Override
	public Edit locateEdit(LocatorType locatorType, String element) {
		return new SeEditImpl(findElement(locatorType, element));
	}

	@Override
	public Button locateButton(LocatorType locatorType, String element) {
		// new SeButtonImpl(findElement(locatorType, Element));
		Button button = new SeButtonImpl(findElement(locatorType, element));
		// return new SeButtonLogDecorator(button);
		return new SeButtonSnapDecorator(new SeButtonLogDecorator(button));
	}

	@Override
	public Link locateLink(LocatorType locatorType, String element) {
		return new SeLinkImpl(findElement(locatorType, element));

	}

	@Override
	public String getTitle() {
		return driver.getTitle();
	}

	@Override
	public void acceptAlert() {
		driver.switchTo().alert().accept();
	}

	@Override
	public void saveStorageState() {
	
		// Capture session storage data
        JavascriptExecutor js = (JavascriptExecutor) driver;
        List<String> sessionKeys = (List<String>) js.executeScript("return Object.keys(sessionStorage);");
        try (FileWriter sessionFile = new FileWriter("storage/session.json")) {
            for (String key : sessionKeys) {
                String value = (String) js.executeScript("return sessionStorage.getItem(arguments[0]);", key);
                sessionFile.write(key + "=" + value + "\n");
            }
            System.out.println("Session storage saved.");
        } catch (IOException e1) {
			e1.printStackTrace();
		}

        // Capture cookies
        try (FileWriter cookieFile = new FileWriter("storage/cookies.json")) {
            for (Cookie cookie : driver.manage().getCookies()) {
                cookieFile.write(cookie.getName() + "=" + cookie.getValue() + "\n");
            }
            System.out.println("Cookies saved.");
        }  catch (Exception e) {
            e.printStackTrace();
        } 

	}
	

	@Override
	public void loadStorageState() {
		 
		try {
			// Restore session storage
			BufferedReader sessionReader = new BufferedReader(new FileReader("storage/session.json"));
			String sessionLine;
			while ((sessionLine = sessionReader.readLine()) != null) {
			    String[] sessionParts = sessionLine.split("=", 2);
			    ((JavascriptExecutor) driver).executeScript(
			        "sessionStorage.setItem(arguments[0], arguments[1]);", sessionParts[0], sessionParts[1]);
			}
			sessionReader.close();

			// Restore cookies
			BufferedReader cookieReader = new BufferedReader(new FileReader("storage/cookies.json"));
			String cookieLine;
			while ((cookieLine = cookieReader.readLine()) != null) {
			    String[] cookieParts = cookieLine.split("=", 2);
			    Cookie cookie = new Cookie(cookieParts[0], cookieParts[1]);
			    driver.manage().addCookie(cookie);
			}
			cookieReader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public byte[] getScreenshot() {
		return ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	}
}
